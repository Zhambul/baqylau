CREATE TRIGGER sessions_lifecycle_after_event
        AFTER INSERT ON canonical_events
        WHEN NEW.event_type IN ('session.started', 'session.finished')
        BEGIN
            UPDATE sessions
            SET lifecycle = CASE NEW.event_type
                WHEN 'session.finished' THEN 'finished'
                ELSE 'running'
            END
            WHERE session_id = NEW.session_id;
        END;

