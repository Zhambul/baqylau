CREATE TRIGGER sessions_lifecycle_after_insert
        AFTER INSERT ON sessions
        BEGIN
            UPDATE sessions
            SET lifecycle = COALESCE((
                SELECT CASE canonical_events.event_type
                    WHEN 'session.finished' THEN 'finished'
                    ELSE 'running'
                END
                FROM canonical_events
                WHERE canonical_events.session_id = NEW.session_id
                  AND canonical_events.event_type IN ('session.started', 'session.finished')
                ORDER BY canonical_events.cursor DESC
                LIMIT 1
            ), 'running')
            WHERE session_id = NEW.session_id;
        END;

